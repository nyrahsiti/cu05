<?php 
$connect=mysqli_connect("localhost", "root","","barangmainan") or die("failed...");
//Sambungan dengan database tidak dapat dibuat
?>

