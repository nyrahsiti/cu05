Delete.php
<?php
include 'config.php'; 
	$kod_produk =$_GET['kod_produk'];// sending query
	$delete= mysqli_query($connect, "DELETE FROM jadual_mainan WHERE kod_produk = '$kod_produk'") ;
		//Table jadual_item salah
	header("Location: index.php");
?>
